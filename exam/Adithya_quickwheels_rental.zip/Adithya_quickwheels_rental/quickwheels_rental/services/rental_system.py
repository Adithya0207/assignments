from data.datastore import DATASTORE
from models.vehicle import Bike, Car, SUV
from services.customer_service import CustomerService
from services.vehicle_service import VehicleService
from services.rental_service import RentalService


class RentalSystem:
    """
    Single facade the UI (main.py) talks to. Keeps main.py free of any
    direct DATASTORE or service-internals knowledge.
    """

    VEHICLE_CLASSES = {
        "bike": Bike,
        "car": Car,
        "suv": SUV,
    }

    def __init__(self):
        self.customer_service = CustomerService()
        self.vehicle_service = VehicleService()
        self.rental_service = RentalService()

    # ---------------- Customers ----------------
    def register_customer(self, person_id, name, age, phone, license_no, wallet=0):
        return self.customer_service.add_customer(
            person_id, name, age, phone, license_no, wallet
        )

    # ---------------- Vehicles ----------------
    def add_vehicle(self, vehicle_type, name, daily_rate, vehicle_id=None):
        vehicle_type = vehicle_type.strip().lower()
        cls = self.VEHICLE_CLASSES.get(vehicle_type)
        if cls is None:
            raise ValueError(f"Unknown vehicle type '{vehicle_type}'. Use bike/car/suv.")
        vehicle = cls(name=name, daily_rate=daily_rate, vehicle_id=vehicle_id)
        return self.vehicle_service.add_vehicle(vehicle)

    def list_vehicles_sorted(self):
        return self.vehicle_service.list_vehicles(sort_by_rate=True)

    # ---------------- Rentals ----------------
    def rent_vehicle(self, cust_id, veh_id, days):
        return self.rental_service.rent(cust_id, veh_id, days)

    def return_vehicle(self, rental_id, actual_days, damage_note=None):
        return self.rental_service.return_vehicle(rental_id, actual_days, damage_note)

    def list_rentals(self):
        return self.rental_service.list_rentals()

    # ---------------- Shutdown / archiving ----------------
    def archive_and_exit(self):
        """
        Called on menu option 7 (Exit). Clearing DATASTORE["rentals"] drops
        the last references to each Rental object, triggering __del__
        (the '[ARCHIVE] Rental #id closed' destructor message) for every
        rental still in memory.
        """
        DATASTORE["rentals"].clear()
