from data.datastore import DATASTORE


class VehicleService:
    """Handles all CRUD operations for vehicles."""

    def add_vehicle(self, vehicle):
        DATASTORE["vehicles"][vehicle.vehicle_id] = vehicle
        return vehicle

    def get_vehicle(self, vehicle_id):
        return DATASTORE["vehicles"].get(vehicle_id)

    def list_vehicles(self, sort_by_rate=False):
        vehicles = list(DATASTORE["vehicles"].values())
        if sort_by_rate:
            vehicles = sorted(vehicles)  # uses Vehicle.__lt__
        return vehicles

    def update_vehicle(self, vehicle_id, **kwargs):
        vehicle = self.get_vehicle(vehicle_id)
        if vehicle is None:
            return False
        for key, value in kwargs.items():
            setattr(vehicle, key, value)
        return True

    def delete_vehicle(self, vehicle_id):
        if vehicle_id in DATASTORE["vehicles"]:
            del DATASTORE["vehicles"][vehicle_id]
            return True
        return False

    def apply_festival_offer(self, vehicle_id, pct):
        """Attach a dynamic `festival_offer` attribute (percent discount) to a vehicle."""
        vehicle = self.get_vehicle(vehicle_id)
        if vehicle is None:
            return False
        setattr(vehicle, "festival_offer", pct)
        return True

    @staticmethod
    def get_festival_offer(vehicle):
        """Billing reads the dynamic attribute safely, defaulting to 0."""
        return getattr(vehicle, "festival_offer", 0)
