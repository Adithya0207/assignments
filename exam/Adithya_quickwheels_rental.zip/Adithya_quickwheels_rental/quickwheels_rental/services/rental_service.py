from data.datastore import DATASTORE
from models.rental import Rental
from utils.validator import is_eligible, is_available, positive_int
from services.vehicle_service import VehicleService
class RentalService:
    """Handles renting, returning, and querying rentals."""

    def __init__(self):
        self._vehicle_service = VehicleService()

    def rent(self, cust_id, veh_id, days):
        if not positive_int(days):
            raise ValueError("days must be a positive integer")

        customer = DATASTORE["customers"].get(cust_id)
        vehicle = DATASTORE["vehicles"].get(veh_id)

        if customer is None:
            raise ValueError(f"Customer '{cust_id}' not found")
        if vehicle is None:
            raise ValueError(f"Vehicle '{veh_id}' not found")

        if not is_eligible(customer):
            raise PermissionError(
                f"Customer '{cust_id}' is not eligible to rent (must be 18+ with a license)"
            )
        if not is_available(vehicle):
            raise ValueError(f"Vehicle '{veh_id}' is not available")

        # Apply festival offer, if any, to the rental cost
        cost = vehicle.rental_cost(days)
        offer_pct = VehicleService.get_festival_offer(vehicle)
        if offer_pct:
            cost = cost * (1 - offer_pct / 100)

        deposit = vehicle.daily_rate * vehicle.deposit_days
        total_charge = cost + deposit

        if not customer.pay(total_charge):
            raise ValueError(
                f"Customer '{cust_id}' has insufficient balance "
                f"(needs ₹{total_charge}, has ₹{customer.balance})"
            )

        vehicle.available = False

        rental = Rental(
            customer=customer,
            vehicle=vehicle,
            planned_days=days,
            amount_paid=cost,
            deposit=deposit,
            status="ACTIVE",
        )
        DATASTORE["rentals"][rental.rental_id] = rental
        return rental

    def return_vehicle(self, rental_id, actual_days, damage_note=None):
        rental = DATASTORE["rentals"].get(rental_id)
        if rental is None:
            raise ValueError(f"Rental '{rental_id}' not found")
        if rental.status == "CLOSED":
            raise ValueError(f"Rental #{rental_id} is already closed")

        vehicle = rental.vehicle
        customer = rental.customer

        extra_days = max(0, actual_days - rental.planned_days)
        late_fee = extra_days * vehicle.daily_rate * 1.5
        damage_fine = 1000 if damage_note else 0

        charges = late_fee + damage_fine
        refund = max(0, rental.deposit - charges)

        if refund > 0:
            customer.add_money(refund)

        vehicle.available = True
        rental.status = "CLOSED"

        if damage_note:
            # Dynamic attribute attached only when there IS a damage note
            setattr(rental, "damage_note", damage_note)

        return {
            "rental_id": rental.rental_id,
            "extra_days": extra_days,
            "late_fee": late_fee,
            "damage_fine": damage_fine,
            "refund": refund,
            "status": rental.status,
        }

    def get_rental(self, rental_id):
        return DATASTORE["rentals"].get(rental_id)

    def list_rentals(self):
        return list(DATASTORE["rentals"].values())

    def delete_rental(self, rental_id):
        if rental_id in DATASTORE["rentals"]:
            del DATASTORE["rentals"][rental_id]
            return True
        return False
