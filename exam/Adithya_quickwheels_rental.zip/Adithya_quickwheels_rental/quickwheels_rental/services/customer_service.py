from data.datastore import DATASTORE
from models.customer import Customer


class CustomerService:
    """Handles all CRUD operations for customers."""

    def add_customer(self, person_id, name, age, phone, license_no, wallet=0):
        if person_id in DATASTORE["customers"]:
            raise ValueError(f"Customer '{person_id}' already exists")
        customer = Customer(person_id, name, age, phone, license_no, wallet)
        DATASTORE["customers"][person_id] = customer
        return customer

    def get_customer(self, person_id):
        return DATASTORE["customers"].get(person_id)

    def list_customers(self):
        return list(DATASTORE["customers"].values())

    def update_phone(self, person_id, new_phone):
        customer = self.get_customer(person_id)
        if customer is None:
            return False
        customer.phone = new_phone
        return True

    def delete_customer(self, person_id):
        if person_id in DATASTORE["customers"]:
            del DATASTORE["customers"][person_id]
            return True
        return False
