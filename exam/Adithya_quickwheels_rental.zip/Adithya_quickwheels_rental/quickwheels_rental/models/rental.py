class Rental:
    """Represents a single rental transaction (invoice)."""

    _rental_id_counter = 5001  # class attribute -> counter starting at 5001

    def __init__(self, customer, vehicle, planned_days, amount_paid, deposit,
                 status="ACTIVE"):
        self.rental_id = Rental._rental_id_counter
        Rental._rental_id_counter += 1

        self.customer = customer
        self.vehicle = vehicle
        self.planned_days = planned_days
        self.amount_paid = amount_paid
        self.deposit = deposit
        self.status = status
        # damage_note is NOT set here; it is optionally attached later via
        # setattr(rental, "damage_note", note) when the vehicle is returned
        # (dynamic attribute).

    def __str__(self):
        note = getattr(self, "damage_note", None)
        base = (f"Rental #{self.rental_id} | Customer: {self.customer.name} | "
                f"Vehicle: {self.vehicle.vehicle_id} ({self.vehicle.name}) | "
                f"Planned days: {self.planned_days} | Paid: ₹{self.amount_paid} | "
                f"Deposit: ₹{self.deposit} | Status: {self.status}")
        if note:
            base += f" | Damage note: {note}"
        return base

    def __del__(self):
        # Destructor: fired when a Rental object is garbage-collected
        # (e.g. archived on exit).
        try:
            print(f"[ARCHIVE] Rental #{self.rental_id} closed")
        except Exception:
            # __del__ must never raise during interpreter shutdown
            pass
