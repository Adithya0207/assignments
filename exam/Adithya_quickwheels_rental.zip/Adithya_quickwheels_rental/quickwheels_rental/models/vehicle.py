class Vehicle:
    """Base class for all rentable vehicles."""

    # ---- class attributes (shared by all vehicles / overridden by subclasses) ----
    company = "QuickWheels"
    id_prefix = "V-"
    deposit_days = 1
    _id_counter = 100  # auto-ID counter

    def __init__(self, name, daily_rate, vehicle_id=None, available=True):
        self.name = name
        self._daily_rate = None
        self.daily_rate = daily_rate  # goes through the property setter (validates > 0)
        self.available = available

        if vehicle_id is None:
            vehicle_id = self._generate_id()
        self.vehicle_id = vehicle_id

    @classmethod
    def _generate_id(cls):
        """Auto-generate a vehicle ID using the subclass's id_prefix and a running counter."""
        cls._id_counter += 1
        return f"{cls.id_prefix}{cls._id_counter}"

    @property
    def daily_rate(self):
        return self._daily_rate

    @daily_rate.setter
    def daily_rate(self, value):
        if value is None or value <= 0:
            raise ValueError("daily_rate must be greater than 0")
        self._daily_rate = value

    def rental_cost(self, days):
        """Base rental cost: rate x days. Subclasses override this."""
        return self.daily_rate * days

    def __eq__(self, other):
        if not isinstance(other, Vehicle):
            return NotImplemented
        return self.vehicle_id == other.vehicle_id

    def __lt__(self, other):
        if not isinstance(other, Vehicle):
            return NotImplemented
        return self.daily_rate < other.daily_rate

    def __str__(self):
        status = "Available" if self.available else "Rented out"
        return (f"{self.vehicle_id} | {self.name} ({self.__class__.__name__}) "
                f"| ₹{self.daily_rate}/day | {status}")


class Bike(Vehicle):
    """Bike -> id_prefix 'B-', deposit_days 1, rental_cost = rate x days."""

    id_prefix = "B-"
    deposit_days = 1
    _id_counter = 100

    def rental_cost(self, days):
        return self.daily_rate * days


class Car(Vehicle):
    """Car -> id_prefix 'C-', deposit_days 2, rental_cost = rate x days x 1.05."""

    id_prefix = "C-"
    deposit_days = 2
    _id_counter = 200

    def rental_cost(self, days):
        return self.daily_rate * days * 1.05


class SUV(Vehicle):
    """SUV -> id_prefix 'S-', deposit_days 3, rental_cost = rate x days + 500."""

    id_prefix = "S-"
    deposit_days = 3
    _id_counter = 300

    def rental_cost(self, days):
        return self.daily_rate * days + 500
