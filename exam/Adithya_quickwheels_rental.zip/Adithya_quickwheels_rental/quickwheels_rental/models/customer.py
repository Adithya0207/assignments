from models.person import Person
class Customer(Person):
    """A customer who can rent vehicles from QuickWheels."""

    def __init__(self, person_id, name, age, phone, license_no, wallet=0):
        super().__init__(person_id, name, age, phone)
        self.license_no = license_no
        self.__wallet = wallet  # private -> name-mangled to _Customer__wallet

    @property
    def balance(self):
        """Read-only balance property."""
        return self.__wallet

    def add_money(self, amount):
        """Add money to the customer's wallet."""
        if amount <= 0:
            return False
        self.__wallet += amount
        return True

    def pay(self, amount):
        """
        Deduct `amount` from wallet if sufficient funds exist.
        Returns True on success, False if balance is insufficient
        (balance remains unchanged in that case).
        """
        if amount <= 0:
            return False
        if amount > self.__wallet:
            return False
        self.__wallet -= amount
        return True

    def __str__(self):
        return (f"Customer[{self.person_id}] {self.name}, age {self.age}, "
                f"license={self.license_no}, balance=₹{self.balance}")
