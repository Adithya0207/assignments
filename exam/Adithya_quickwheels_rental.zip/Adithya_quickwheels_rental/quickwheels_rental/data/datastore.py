DATASTORE = {
    "customers": {},  # "CU01" -> Customer
    "vehicles": {},   # "B-101" -> Bike / Car / SUV
    "rentals": {}      # 5001 -> Rental
}


def reset_datastore():
    """Clear all tables. Useful for tests (called from each test's setUp())."""
    DATASTORE["customers"].clear()
    DATASTORE["vehicles"].clear()
    DATASTORE["rentals"].clear()
