from data.datastore import DATASTORE
from models.customer import Customer
from models.vehicle import Bike, Car, SUV


def load_seed_data():
    """Populate DATASTORE with the sample vehicles and customers."""

    # ---- Vehicles ----
    bike = Bike(name="Honda Activa", daily_rate=400, vehicle_id="B-101")
    car = Car(name="Maruti Swift", daily_rate=1800, vehicle_id="C-201")
    suv = SUV(name="Toyota Innova", daily_rate=3500, vehicle_id="S-301")

    for v in (bike, car, suv):
        DATASTORE["vehicles"][v.vehicle_id] = v

    # ---- Customers ----
    cu01 = Customer(person_id="CU01", name="Arjun", age=24, phone="9000000001",
                     license_no="TN10-2021-0042", wallet=5000)
    cu02 = Customer(person_id="CU02", name="Meera", age=31, phone="9000000002",
                     license_no="TN22-2018-0913", wallet=15000)
    # Rahul: 17 years old, no license -> stored as None, deliberately ineligible
    cu03 = Customer(person_id="CU03", name="Rahul", age=17, phone="9000000003",
                     license_no=None, wallet=2000)

    for c in (cu01, cu02, cu03):
        DATASTORE["customers"][c.person_id] = c
