import unittest

from data.datastore import reset_datastore
from models.vehicle import Bike, Car, SUV


class TestVehicle(unittest.TestCase):

    def setUp(self):
        reset_datastore()

    def test_rental_cost_overriding(self):
        bike = Bike(name="Honda Activa", daily_rate=400)
        car = Car(name="Maruti Swift", daily_rate=1800)
        suv = SUV(name="Toyota Innova", daily_rate=3500)

        self.assertEqual(bike.rental_cost(2), 800)
        self.assertEqual(car.rental_cost(2), 3780)
        self.assertEqual(suv.rental_cost(2), 7500)

    def test_rate_validation(self):
        bike = Bike(name="Honda Activa", daily_rate=400)

        with self.assertRaises(ValueError):
            bike.daily_rate = 0

        with self.assertRaises(ValueError):
            bike.daily_rate = -100


if __name__ == "__main__":
    unittest.main()
