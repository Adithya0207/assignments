import unittest

from data.datastore import DATASTORE, reset_datastore
from services.customer_service import CustomerService


class TestCustomer(unittest.TestCase):

    def setUp(self):
        # Clear the datastore so each test starts from a fresh database.
        reset_datastore()
        self.service = CustomerService()

    def test_add_customer(self):
        customer = self.service.add_customer(
            person_id="CU01",
            name="Arjun",
            age=24,
            phone="9000000001",
            license_no="TN10-2021-0042",
            wallet=5000,
        )
        self.assertIn("CU01", DATASTORE["customers"])
        self.assertIs(DATASTORE["customers"]["CU01"], customer)

    def test_wallet_encapsulation(self):
        customer = self.service.add_customer(
            person_id="CU01",
            name="Arjun",
            age=24,
            phone="9000000001",
            license_no="TN10-2021-0042",
            wallet=100,
        )

        # Paying more than the balance should fail and leave balance unchanged.
        result = customer.pay(500)
        self.assertFalse(result)
        self.assertEqual(customer.balance, 100)

        # Direct access to the name-mangled private attribute must fail.
        with self.assertRaises(AttributeError):
            _ = customer.__wallet


if __name__ == "__main__":
    unittest.main()
