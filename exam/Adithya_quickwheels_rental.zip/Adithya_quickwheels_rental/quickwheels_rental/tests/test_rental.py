import unittest

from data.datastore import DATASTORE, reset_datastore
from models.customer import Customer
from models.vehicle import Bike
from services.rental_service import RentalService


class TestRental(unittest.TestCase):

    def setUp(self):
        reset_datastore()
        self.rental_service = RentalService()

        # Eligible customer: Arjun, 24, has a license.
        self.arjun = Customer(
            person_id="CU01", name="Arjun", age=24, phone="9000000001",
            license_no="TN10-2021-0042", wallet=5000
        )
        DATASTORE["customers"]["CU01"] = self.arjun

        # Ineligible customer: Rahul, 17, no license.
        self.rahul = Customer(
            person_id="CU03", name="Rahul", age=17, phone="9000000003",
            license_no=None, wallet=2000
        )
        DATASTORE["customers"]["CU03"] = self.rahul

        self.bike = Bike(name="Honda Activa", daily_rate=400, vehicle_id="B-101")
        DATASTORE["vehicles"]["B-101"] = self.bike

    def test_rent_success(self):
        starting_balance = self.arjun.balance
        days = 2

        rental = self.rental_service.rent("CU01", "B-101", days)

        # Rental is stored in the datastore.
        self.assertIn(rental.rental_id, DATASTORE["rentals"])

        # Vehicle is now unavailable.
        self.assertFalse(self.bike.available)

        # Wallet debited exactly cost + deposit.
        cost = self.bike.rental_cost(days)              # 400 * 2 = 800
        deposit = self.bike.daily_rate * self.bike.deposit_days  # 400 * 1 = 400
        expected_balance = starting_balance - (cost + deposit)

        self.assertEqual(self.arjun.balance, expected_balance)

    def test_ineligible_blocked(self):
        with self.assertRaises(PermissionError):
            self.rental_service.rent("CU03", "B-101", 2)

        # Nothing should have been stored.
        self.assertEqual(len(DATASTORE["rentals"]), 0)
        # Vehicle should still be available since rental was refused.
        self.assertTrue(self.bike.available)


if __name__ == "__main__":
    unittest.main()
