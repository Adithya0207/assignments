from data.seed_data import load_seed_data
from services.rental_system import RentalSystem
MENU = """
====== QUICKWHEELS VEHICLE RENTAL ======
 1. Register customer
 2. Add vehicle
 3. View vehicles (sorted by rate)
 4. Rent a vehicle
 5. Return a vehicle
 6. View rentals
 7. Exit (archive rentals -> destructors fire)
=========================================
"""


def register_customer(system):
    try:
        person_id = input("Customer ID (e.g. CU04): ").strip()
        name = input("Name: ").strip()
        age = int(input("Age: ").strip())
        phone = input("Phone: ").strip()
        license_no = input("License number (blank if none): ").strip() or None
        wallet = float(input("Starting wallet amount: ").strip() or 0)
        customer = system.register_customer(person_id, name, age, phone, license_no, wallet)
        print(f"Registered: {customer}")
    except ValueError as e:
        print(f"Could not register customer: {e}")


def add_vehicle(system):
    try:
        vtype = input("Vehicle type (bike/car/suv): ").strip()
        name = input("Vehicle name (e.g. Honda Activa): ").strip()
        rate = float(input("Daily rate: ").strip())
        vehicle_id = input("Vehicle ID (blank to auto-generate): ").strip() or None
        vehicle = system.add_vehicle(vtype, name, rate, vehicle_id)
        print(f"Added: {vehicle}")
    except ValueError as e:
        print(f"Could not add vehicle: {e}")


def view_vehicles(system):
    vehicles = system.list_vehicles_sorted()
    if not vehicles:
        print("No vehicles in the system yet.")
        return
    print("\n-- Vehicles (sorted by daily rate) --")
    for v in vehicles:
        print(v)


def rent_vehicle(system):
    try:
        cust_id = input("Customer ID: ").strip()
        veh_id = input("Vehicle ID: ").strip()
        days = int(input("Number of days: ").strip())
        rental = system.rent_vehicle(cust_id, veh_id, days)
        print(f"Rental created: {rental}")
    except (ValueError, PermissionError) as e:
        print(f"Could not complete rental: {e}")


def return_vehicle(system):
    try:
        rental_id = int(input("Rental ID: ").strip())
        actual_days = int(input("Actual days used: ").strip())
        damage_note = input("Damage note (blank if none): ").strip() or None
        result = system.return_vehicle(rental_id, actual_days, damage_note)
        print(f"Return processed: {result}")
    except ValueError as e:
        print(f"Could not process return: {e}")


def view_rentals(system):
    rentals = system.list_rentals()
    if not rentals:
        print("No rentals in the system yet.")
        return
    print("\n-- Rentals --")
    for r in rentals:
        print(r)


def main():
    load_seed_data()
    system = RentalSystem()

    actions = {
        "1": register_customer,
        "2": add_vehicle,
        "3": view_vehicles,
        "4": rent_vehicle,
        "5": return_vehicle,
        "6": view_rentals,
    }

    while True:
        print(MENU)
        choice = input("Choose an option (1-7): ").strip()

        if choice == "7":
            print("Archiving rentals and exiting...")
            system.archive_and_exit()
            print("Goodbye!")
            break

        action = actions.get(choice)
        if action is None:
            print("Invalid choice, please try again.")
            continue

        action(system)


if __name__ == "__main__":
    main()
