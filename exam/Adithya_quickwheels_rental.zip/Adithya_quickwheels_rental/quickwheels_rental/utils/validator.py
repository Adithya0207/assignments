def is_eligible(customer):
    """A customer is eligible to rent if they are 18+ and hold a license."""
    if customer is None:
        return False
    has_license = bool(getattr(customer, "license_no", None))
    return customer.age >= 18 and has_license


def is_available(vehicle):
    """A vehicle can be rented only if it is currently marked available."""
    if vehicle is None:
        return False
    return vehicle.available is True


def positive_int(value):
    """Return True if value is an int (or int-like) and strictly positive."""
    try:
        return int(value) > 0
    except (TypeError, ValueError):
        return False
