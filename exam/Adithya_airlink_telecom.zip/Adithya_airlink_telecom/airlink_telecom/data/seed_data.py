from data.datastore import DATASTORE
from models.subscriber import Subscriber
from models.plan import Prepaid, Postpaid, DataPack


def load_seed_data():
    """Populate DATASTORE with the sample plans and subscribers."""

    # ---- Plans ----
    prepaid = Prepaid(name="Smart Saver", monthly_price=200, plan_id="PRE-101")
    postpaid = Postpaid(name="Business Pro", monthly_price=500, plan_id="POST-201")
    datapack = DataPack(name="NetMax 2GB/day", monthly_price=300, plan_id="DATA-301",
                         data_per_day="2GB")

    for p in (prepaid, postpaid, datapack):
        DATASTORE["plans"][p.plan_id] = p

    # ---- Subscribers ----
    sub01 = Subscriber(person_id="SUB01", name="Karthik", age=26, phone="9000000001",
                        mobile_no="9000000001", id_proof="AAD-4821-9034", balance=2000)
    sub02 = Subscriber(person_id="SUB02", name="Divya", age=34, phone="9000000002",
                        mobile_no="9000000002", id_proof="AAD-7733-1268", balance=5000)
    # Vimal: 16 years old, no ID proof -> stored as None, deliberately ineligible
    sub03 = Subscriber(person_id="SUB03", name="Vimal", age=16, phone="9000000003",
                        mobile_no="9000000003", id_proof=None, balance=500)

    for s in (sub01, sub02, sub03):
        DATASTORE["subscribers"][s.person_id] = s

    # Connections start empty -- nothing to seed here.
