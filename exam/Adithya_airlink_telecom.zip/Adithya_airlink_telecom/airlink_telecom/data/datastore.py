DATASTORE = {
    "subscribers": {},   # "SUB01" -> Subscriber
    "plans": {},         # "POST-201" -> Prepaid / Postpaid / DataPack
    "connections": {}    # 9001 -> Connection
}


def reset_datastore():
    """Clear all tables. Useful for tests (called from each test's setUp())."""
    DATASTORE["subscribers"].clear()
    DATASTORE["plans"].clear()
    DATASTORE["connections"].clear()
