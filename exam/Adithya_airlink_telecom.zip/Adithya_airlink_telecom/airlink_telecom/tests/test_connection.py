import unittest

from data.datastore import DATASTORE, reset_datastore
from models.subscriber import Subscriber
from models.plan import Prepaid
from services.connection_service import ConnectionService


class TestConnection(unittest.TestCase):

    def setUp(self):
        reset_datastore()
        self.connection_service = ConnectionService()

        # Eligible subscriber: Karthik, 26, has ID proof.
        self.karthik = Subscriber(
            person_id="SUB01", name="Karthik", age=26, phone="9000000001",
            mobile_no="9000000001", id_proof="AAD-4821-9034", balance=2000
        )
        DATASTORE["subscribers"]["SUB01"] = self.karthik

        # Ineligible subscriber: Vimal, 16, no ID proof.
        self.vimal = Subscriber(
            person_id="SUB03", name="Vimal", age=16, phone="9000000003",
            mobile_no="9000000003", id_proof=None, balance=500
        )
        DATASTORE["subscribers"]["SUB03"] = self.vimal

        self.prepaid = Prepaid(name="Smart Saver", monthly_price=200, plan_id="PRE-101")
        DATASTORE["plans"]["PRE-101"] = self.prepaid

    def test_activate_success(self):
        starting_balance = self.karthik.balance
        months = 2

        connection = self.connection_service.activate("SUB01", "PRE-101", months)

        # Connection is stored in the datastore.
        self.assertIn(connection.connection_id, DATASTORE["connections"])

        # Status is ACTIVE.
        self.assertEqual(connection.status, "ACTIVE")

        # Balance debited exactly bill + activation_fee.
        bill = self.prepaid.bill(months)               # 200 * 2 = 400
        expected_balance = starting_balance - (bill + self.prepaid.activation_fee)  # activation_fee = 0

        self.assertEqual(self.karthik.balance, expected_balance)

    def test_ineligible_blocked(self):
        with self.assertRaises(PermissionError):
            self.connection_service.activate("SUB03", "PRE-101", 2)

        # Nothing should have been stored.
        self.assertEqual(len(DATASTORE["connections"]), 0)


if __name__ == "__main__":
    unittest.main()
