
import unittest
from data.datastore import DATASTORE, reset_datastore
from services.subscriber_service import SubscriberService


class TestSubscriber(unittest.TestCase):

    def setUp(self):
        # Clear the datastore so each test starts from a fresh database.
        reset_datastore()
        self.service = SubscriberService()

    def test_add_subscriber(self):
        subscriber = self.service.add_subscriber(
            person_id="SUB01",
            name="Karthik",
            age=26,
            phone="9000000001",
            mobile_no="9000000001",
            id_proof="AAD-4821-9034",
            balance=2000,
        )
        self.assertIn("SUB01", DATASTORE["subscribers"])
        self.assertIs(DATASTORE["subscribers"]["SUB01"], subscriber)

    def test_balance_encapsulation(self):
        subscriber = self.service.add_subscriber(
            person_id="SUB01",
            name="Karthik",
            age=26,
            phone="9000000001",
            mobile_no="9000000001",
            id_proof="AAD-4821-9034",
            balance=100,
        )

        # Deducting more than the balance should fail and leave balance unchanged.
        result = subscriber.deduct(500)
        self.assertFalse(result)
        self.assertEqual(subscriber.balance, 100)

        # Direct access to the name-mangled private attribute must fail.
        with self.assertRaises(AttributeError):
            _ = subscriber.__balance


if __name__ == "__main__":
    unittest.main()
