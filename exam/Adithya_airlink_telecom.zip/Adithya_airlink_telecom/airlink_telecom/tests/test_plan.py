import unittest

from data.datastore import reset_datastore
from models.plan import Prepaid, Postpaid, DataPack


class TestPlan(unittest.TestCase):

    def setUp(self):
        reset_datastore()

    def test_bill_overriding(self):
        prepaid = Prepaid(name="Smart Saver", monthly_price=200)
        postpaid = Postpaid(name="Business Pro", monthly_price=500)
        datapack = DataPack(name="NetMax 2GB/day", monthly_price=300)

        self.assertEqual(prepaid.bill(2), 400)
        self.assertEqual(postpaid.bill(2), 1180)
        self.assertEqual(datapack.bill(2), 650)

    def test_price_validation(self):
        prepaid = Prepaid(name="Smart Saver", monthly_price=200)

        with self.assertRaises(ValueError):
            prepaid.monthly_price = 0

        with self.assertRaises(ValueError):
            prepaid.monthly_price = -50


if __name__ == "__main__":
    unittest.main()
