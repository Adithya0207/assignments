from data.seed_data import load_seed_data
from services.telecom_system import TelecomSystem


MENU = """
======= AIRLINK TELECOM PORTAL =======
 1. Register subscriber
 2. Add plan
 3. View plans (sorted by price)
 4. Activate a connection
 5. Deactivate a connection
 6. View connections
 7. Exit (archive connections -> destructors fire)
=======================================
"""


def register_subscriber(system):
    try:
        person_id = input("Subscriber ID (e.g. SUB04): ").strip()
        name = input("Name: ").strip()
        age = int(input("Age: ").strip())
        phone = input("Phone: ").strip()
        mobile_no = input("Mobile number: ").strip()
        id_proof = input("ID proof (blank if none): ").strip() or None
        balance = float(input("Starting balance: ").strip() or 0)
        subscriber = system.register_subscriber(
            person_id, name, age, phone, mobile_no, id_proof, balance
        )
        print(f"Registered: {subscriber}")
    except ValueError as e:
        print(f"Could not register subscriber: {e}")


def add_plan(system):
    try:
        ptype = input("Plan type (prepaid/postpaid/datapack): ").strip()
        name = input("Plan name (e.g. Smart Saver): ").strip()
        price = float(input("Monthly price: ").strip())
        plan_id = input("Plan ID (blank to auto-generate): ").strip() or None
        data_per_day = input("Data per day (blank if n/a): ").strip() or None
        plan = system.add_plan(ptype, name, price, plan_id, data_per_day)
        print(f"Added: {plan}")
    except ValueError as e:
        print(f"Could not add plan: {e}")


def view_plans(system):
    plans = system.list_plans_sorted()
    if not plans:
        print("No plans in the system yet.")
        return
    print("\n-- Plans (sorted by monthly price) --")
    for p in plans:
        print(p)


def activate_connection(system):
    try:
        sub_id = input("Subscriber ID: ").strip()
        plan_id = input("Plan ID: ").strip()
        months = int(input("Number of months: ").strip())
        connection = system.activate_connection(sub_id, plan_id, months)
        print(f"Connection activated: {connection}")
    except (ValueError, PermissionError) as e:
        print(f"Could not activate connection: {e}")


def deactivate_connection(system):
    try:
        conn_id = int(input("Connection ID: ").strip())
        used_months = int(input("Months actually used: ").strip())
        port_out_input = input("Porting out? (y/n): ").strip().lower()
        port_out = port_out_input == "y"
        result = system.deactivate_connection(conn_id, used_months, port_out)
        print(f"Deactivation processed: {result}")
    except ValueError as e:
        print(f"Could not process deactivation: {e}")


def view_connections(system):
    connections = system.list_connections()
    if not connections:
        print("No connections in the system yet.")
        return
    print("\n-- Connections --")
    for c in connections:
        print(c)


def main():
    load_seed_data()
    system = TelecomSystem()

    actions = {
        "1": register_subscriber,
        "2": add_plan,
        "3": view_plans,
        "4": activate_connection,
        "5": deactivate_connection,
        "6": view_connections,
    }

    while True:
        print(MENU)
        choice = input("Choose an option (1-7): ").strip()

        if choice == "7":
            print("Archiving connections and exiting...")
            system.archive_and_exit()
            print("Goodbye!")
            break

        action = actions.get(choice)
        if action is None:
            print("Invalid choice, please try again.")
            continue

        action(system)


if __name__ == "__main__":
    main()
