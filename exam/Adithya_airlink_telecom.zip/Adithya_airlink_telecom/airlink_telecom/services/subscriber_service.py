from data.datastore import DATASTORE
from models.subscriber import Subscriber


class SubscriberService:
    """Handles all CRUD operations for subscribers."""

    def add_subscriber(self, person_id, name, age, phone, mobile_no, id_proof, balance=0):
        if person_id in DATASTORE["subscribers"]:
            raise ValueError(f"Subscriber '{person_id}' already exists")
        subscriber = Subscriber(person_id, name, age, phone, mobile_no, id_proof, balance)
        DATASTORE["subscribers"][person_id] = subscriber
        return subscriber

    def get_subscriber(self, person_id):
        return DATASTORE["subscribers"].get(person_id)

    def list_subscribers(self):
        return list(DATASTORE["subscribers"].values())

    def update_phone(self, person_id, new_phone):
        subscriber = self.get_subscriber(person_id)
        if subscriber is None:
            return False
        subscriber.phone = new_phone
        return True

    def delete_subscriber(self, person_id):
        if person_id in DATASTORE["subscribers"]:
            del DATASTORE["subscribers"][person_id]
            return True
        return False
