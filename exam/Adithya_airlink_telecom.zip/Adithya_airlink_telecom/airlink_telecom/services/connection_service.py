from data.datastore import DATASTORE
from models.connection import Connection
from utils.validator import is_eligible, has_active_connection, positive_int
from services.plan_service import PlanService


class ConnectionService:
    """Handles activating, deactivating, and querying connections."""

    def __init__(self):
        self._plan_service = PlanService()

    def activate(self, sub_id, plan_id, months):
        if not positive_int(months):
            raise ValueError("months must be a positive integer")

        subscriber = DATASTORE["subscribers"].get(sub_id)
        plan = DATASTORE["plans"].get(plan_id)

        if subscriber is None:
            raise ValueError(f"Subscriber '{sub_id}' not found")
        if plan is None:
            raise ValueError(f"Plan '{plan_id}' not found")

        if not is_eligible(subscriber):
            raise PermissionError(
                f"Subscriber '{sub_id}' is not eligible to activate a connection "
                f"(must be 18+ with ID proof)"
            )
        if has_active_connection(sub_id):
            raise ValueError(f"Subscriber '{sub_id}' already has an active connection")

        # Apply festival offer, if any, to the bill
        bill = plan.bill(months)
        offer_pct = PlanService.get_festival_offer(plan)
        if offer_pct:
            bill = bill * (1 - offer_pct / 100)

        total_charge = bill + plan.activation_fee

        if not subscriber.deduct(total_charge):
            raise ValueError(
                f"Subscriber '{sub_id}' has insufficient balance "
                f"(needs ₹{total_charge}, has ₹{subscriber.balance})"
            )

        connection = Connection(
            subscriber=subscriber,
            plan=plan,
            months=months,
            amount_paid=bill,
            status="ACTIVE",
        )
        DATASTORE["connections"][connection.connection_id] = connection
        return connection

    def deactivate(self, conn_id, used_months, port_out=False):
        connection = DATASTORE["connections"].get(conn_id)
        if connection is None:
            raise ValueError(f"Connection '{conn_id}' not found")
        if connection.status == "DEACTIVATED":
            raise ValueError(f"Connection #{conn_id} is already deactivated")

        plan = connection.plan
        subscriber = connection.subscriber

        remaining_months = max(0, connection.months - used_months)
        base_refund = remaining_months * plan.monthly_price * 0.5

        if port_out:
            refund = max(0, base_refund - 150)
        else:
            refund = max(0, base_refund)

        if refund > 0:
            subscriber.recharge(refund)

        connection.status = "DEACTIVATED"

        if port_out:
            # Dynamic attribute attached only when porting out
            setattr(connection, "port_out_note", "Ported out to another operator")

        return {
            "connection_id": connection.connection_id,
            "remaining_months": remaining_months,
            "refund": refund,
            "status": connection.status,
        }

    def get_connection(self, conn_id):
        return DATASTORE["connections"].get(conn_id)

    def list_connections(self):
        return list(DATASTORE["connections"].values())

    def delete_connection(self, conn_id):
        if conn_id in DATASTORE["connections"]:
            del DATASTORE["connections"][conn_id]
            return True
        return False
