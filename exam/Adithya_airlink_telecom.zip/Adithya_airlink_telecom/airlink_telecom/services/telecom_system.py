from data.datastore import DATASTORE
from models.plan import Prepaid, Postpaid, DataPack
from services.subscriber_service import SubscriberService
from services.plan_service import PlanService
from services.connection_service import ConnectionService


class TelecomSystem:
    """
    Single facade the UI (main.py) talks to. Keeps main.py free of any
    direct DATASTORE or service-internals knowledge.
    """

    PLAN_CLASSES = {
        "prepaid": Prepaid,
        "postpaid": Postpaid,
        "datapack": DataPack,
    }

    def __init__(self):
        self.subscriber_service = SubscriberService()
        self.plan_service = PlanService()
        self.connection_service = ConnectionService()

    # ---------------- Subscribers ----------------
    def register_subscriber(self, person_id, name, age, phone, mobile_no, id_proof, balance=0):
        return self.subscriber_service.add_subscriber(
            person_id, name, age, phone, mobile_no, id_proof, balance
        )

    # ---------------- Plans ----------------
    def add_plan(self, plan_type, name, monthly_price, plan_id=None, data_per_day=None):
        plan_type = plan_type.strip().lower()
        cls = self.PLAN_CLASSES.get(plan_type)
        if cls is None:
            raise ValueError(f"Unknown plan type '{plan_type}'. Use prepaid/postpaid/datapack.")
        plan = cls(name=name, monthly_price=monthly_price, plan_id=plan_id,
                   data_per_day=data_per_day)
        return self.plan_service.add_plan(plan)

    def list_plans_sorted(self):
        return self.plan_service.list_plans(sort_by_price=True)

    # ---------------- Connections ----------------
    def activate_connection(self, sub_id, plan_id, months):
        return self.connection_service.activate(sub_id, plan_id, months)

    def deactivate_connection(self, conn_id, used_months, port_out=False):
        return self.connection_service.deactivate(conn_id, used_months, port_out)

    def list_connections(self):
        return self.connection_service.list_connections()

    # ---------------- Shutdown / archiving ----------------
    def archive_and_exit(self):
        """
        Called on menu option 7 (Exit). Clearing DATASTORE["connections"]
        drops the last references to each Connection object, triggering
        __del__ (the '[ARCHIVE] Connection #id closed' destructor message)
        for every connection still in memory.
        """
        DATASTORE["connections"].clear()
