from data.datastore import DATASTORE


class PlanService:
    """Handles all CRUD operations for plans."""

    def add_plan(self, plan):
        DATASTORE["plans"][plan.plan_id] = plan
        return plan

    def get_plan(self, plan_id):
        return DATASTORE["plans"].get(plan_id)

    def list_plans(self, sort_by_price=False):
        plans = list(DATASTORE["plans"].values())
        if sort_by_price:
            plans = sorted(plans)  # uses Plan.__lt__
        return plans

    def update_plan(self, plan_id, **kwargs):
        plan = self.get_plan(plan_id)
        if plan is None:
            return False
        for key, value in kwargs.items():
            setattr(plan, key, value)
        return True

    def delete_plan(self, plan_id):
        if plan_id in DATASTORE["plans"]:
            del DATASTORE["plans"][plan_id]
            return True
        return False

    def apply_festival_offer(self, plan_id, pct):
        """Attach a dynamic `festival_offer` attribute (percent discount) to a plan."""
        plan = self.get_plan(plan_id)
        if plan is None:
            return False
        setattr(plan, "festival_offer", pct)
        return True

    @staticmethod
    def get_festival_offer(plan):
        """Billing reads the dynamic attribute safely, defaulting to 0."""
        return getattr(plan, "festival_offer", 0)
