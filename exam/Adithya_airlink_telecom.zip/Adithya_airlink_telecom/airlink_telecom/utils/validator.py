from data.datastore import DATASTORE


def is_eligible(subscriber):
    """A subscriber is eligible to activate a connection if 18+ and holds ID proof."""
    if subscriber is None:
        return False
    has_id_proof = bool(getattr(subscriber, "id_proof", None))
    return subscriber.age >= 18 and has_id_proof


def has_active_connection(subscriber_id):
    """Return True if the subscriber already has an ACTIVE connection (one-active-connection rule)."""
    for connection in DATASTORE["connections"].values():
        if connection.subscriber.person_id == subscriber_id and connection.status == "ACTIVE":
            return True
    return False


def positive_int(value):
    """Return True if value is an int (or int-like) and strictly positive."""
    try:
        return int(value) > 0
    except (TypeError, ValueError):
        return False
