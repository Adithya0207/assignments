class Connection:
    """Represents a single connection (a subscriber activated on a plan)."""

    _connection_id_counter = 9001  # class attribute -> counter starting at 9001

    def __init__(self, subscriber, plan, months, amount_paid, status="ACTIVE"):
        self.connection_id = Connection._connection_id_counter
        Connection._connection_id_counter += 1

        self.subscriber = subscriber
        self.plan = plan
        self.months = months
        self.amount_paid = amount_paid
        self.status = status
        # port_out_note is NOT set here; it is optionally attached later via
        # setattr(connection, "port_out_note", note) at deactivation
        # (dynamic attribute).

    def __str__(self):
        note = getattr(self, "port_out_note", None)
        base = (f"Connection #{self.connection_id} | Subscriber: {self.subscriber.name} | "
                f"Plan: {self.plan.plan_id} ({self.plan.name}) | Months: {self.months} | "
                f"Paid: ₹{self.amount_paid} | Status: {self.status}")
        if note:
            base += f" | Port-out note: {note}"
        return base

    def __del__(self):
        # Destructor: fired when a Connection object is garbage-collected
        # (e.g. archived on exit).
        try:
            print(f"[ARCHIVE] Connection #{self.connection_id} closed")
        except Exception:
            # __del__ must never raise during interpreter shutdown
            pass
