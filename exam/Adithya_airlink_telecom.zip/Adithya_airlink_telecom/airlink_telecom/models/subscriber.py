from models.person import Person


class Subscriber(Person):
    """A subscriber who can activate connections on AirLink plans."""

    def __init__(self, person_id, name, age, phone, mobile_no, id_proof, balance=0):
        super().__init__(person_id, name, age, phone)
        self.mobile_no = mobile_no
        self.id_proof = id_proof
        self.__balance = balance  # private -> name-mangled to _Subscriber__balance

    @property
    def balance(self):
        """Read-only balance property."""
        return self.__balance

    def recharge(self, amount):
        """Add money to the subscriber's balance."""
        if amount <= 0:
            return False
        self.__balance += amount
        return True

    def deduct(self, amount):
        """
        Deduct `amount` from balance if sufficient funds exist.
        Returns True on success, False if balance is insufficient
        (balance remains unchanged in that case).
        """
        if amount <= 0:
            return False
        if amount > self.__balance:
            return False
        self.__balance -= amount
        return True

    def __str__(self):
        return (f"Subscriber[{self.person_id}] {self.name}, age {self.age}, "
                f"id_proof={self.id_proof}, balance=₹{self.balance}")
