class Person:
    """Base class for any person in the AirLink system."""

    def __init__(self, person_id, name, age, phone):
        self.person_id = person_id
        self.name = name
        self.age = age
        self.phone = phone

    def __str__(self):
        return f"Person[{self.person_id}] {self.name}, age {self.age}, phone {self.phone}"
