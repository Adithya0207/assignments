class Plan:
    """Base class for all AirLink plans."""

    # ---- class attributes (shared by all plans / overridden by subclasses) ----
    company = "AirLink"
    id_prefix = "P-"
    activation_fee = 0
    _id_counter = 100  # auto-ID counter

    def __init__(self, name, monthly_price, data_per_day=None, plan_id=None):
        self.name = name
        self.data_per_day = data_per_day
        self._monthly_price = None
        self.monthly_price = monthly_price  # goes through the property setter (validates > 0)

        if plan_id is None:
            plan_id = self._generate_id()
        self.plan_id = plan_id

    @classmethod
    def _generate_id(cls):
        """Auto-generate a plan ID using the subclass's id_prefix and a running counter."""
        cls._id_counter += 1
        return f"{cls.id_prefix}{cls._id_counter}"

    @property
    def monthly_price(self):
        return self._monthly_price

    @monthly_price.setter
    def monthly_price(self, value):
        if value is None or value <= 0:
            raise ValueError("monthly_price must be greater than 0")
        self._monthly_price = value

    def bill(self, months):
        """Base bill: price x months. Subclasses override this."""
        return self.monthly_price * months

    def __eq__(self, other):
        if not isinstance(other, Plan):
            return NotImplemented
        return self.plan_id == other.plan_id

    def __lt__(self, other):
        if not isinstance(other, Plan):
            return NotImplemented
        return self.monthly_price < other.monthly_price

    def __str__(self):
        return (f"{self.plan_id} | {self.name} ({self.__class__.__name__}) "
                f"| ₹{self.monthly_price}/month")


class Prepaid(Plan):
    """Prepaid -> id_prefix 'PRE-', activation_fee 0, bill = price x months."""

    id_prefix = "PRE-"
    activation_fee = 0
    _id_counter = 100

    def bill(self, months):
        return self.monthly_price * months


class Postpaid(Plan):
    """Postpaid -> id_prefix 'POST-', activation_fee 100, bill = price x months x 1.18 (18% GST)."""

    id_prefix = "POST-"
    activation_fee = 100
    _id_counter = 200

    def bill(self, months):
        return self.monthly_price * months * 1.18


class DataPack(Plan):
    """DataPack -> id_prefix 'DATA-', activation_fee 50, bill = price x months + 50."""

    id_prefix = "DATA-"
    activation_fee = 50
    _id_counter = 300

    def bill(self, months):
        return self.monthly_price * months + 50
