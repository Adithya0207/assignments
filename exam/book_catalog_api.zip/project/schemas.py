from datetime import datetime
from typing import Optional
from enum import Enum

from pydantic import BaseModel, ConfigDict


class StatusEnum(str, Enum):
    available = "available"
    borrowed = "borrowed"


class BookBase(BaseModel):
    title: str
    author: str
    genre: Optional[str] = None
    status: StatusEnum = StatusEnum.available


class BookCreate(BookBase):
    pass


class BookUpdate(BaseModel):
    title: Optional[str] = None
    author: Optional[str] = None
    genre: Optional[str] = None
    status: Optional[StatusEnum] = None


class BookOut(BookBase):
    model_config = ConfigDict(from_attributes=True)

    id: int
    added_at: datetime
