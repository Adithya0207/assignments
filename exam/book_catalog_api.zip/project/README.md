# Book Catalog API

## Run locally

1. `pip install -r requirements.txt`
2. `uvicorn main:app --reload`
3. Open `http://127.0.0.1:8000` in your browser.
