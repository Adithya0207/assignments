const API_URL = "/books";

const form = document.getElementById("book-form");
const bookIdInput = document.getElementById("book-id");
const titleInput = document.getElementById("title");
const authorInput = document.getElementById("author");
const genreInput = document.getElementById("genre");
const statusInput = document.getElementById("status");
const submitBtn = document.getElementById("submit-btn");
const cancelBtn = document.getElementById("cancel-btn");
const booksBody = document.getElementById("books-body");

async function fetchBooks() {
  const res = await fetch(API_URL);
  const books = await res.json();
  renderBooks(books);
}

function renderBooks(books) {
  booksBody.innerHTML = "";
  books.forEach((book) => {
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${book.id}</td>
      <td>${book.title}</td>
      <td>${book.author}</td>
      <td>${book.genre ?? ""}</td>
      <td>${book.status}</td>
      <td>${new Date(book.added_at).toLocaleString()}</td>
      <td>
        <button class="action-btn" data-action="edit" data-id="${book.id}">Edit</button>
        <button class="action-btn" data-action="delete" data-id="${book.id}">Delete</button>
      </td>
    `;
    booksBody.appendChild(row);
  });
}

function resetForm() {
  bookIdInput.value = "";
  form.reset();
  submitBtn.textContent = "Add Book";
  cancelBtn.style.display = "none";
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();

  const payload = {
    title: titleInput.value,
    author: authorInput.value,
    genre: genreInput.value || null,
    status: statusInput.value,
  };

  const id = bookIdInput.value;

  if (id) {
    await fetch(`${API_URL}/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  } else {
    await fetch(API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
  }

  resetForm();
  fetchBooks();
});

cancelBtn.addEventListener("click", resetForm);

booksBody.addEventListener("click", async (e) => {
  const target = e.target;
  const id = target.getAttribute("data-id");
  const action = target.getAttribute("data-action");

  if (!id || !action) return;

  if (action === "delete") {
    await fetch(`${API_URL}/${id}`, { method: "DELETE" });
    fetchBooks();
  }

  if (action === "edit") {
    const res = await fetch(`${API_URL}/${id}`);
    const book = await res.json();
    bookIdInput.value = book.id;
    titleInput.value = book.title;
    authorInput.value = book.author;
    genreInput.value = book.genre ?? "";
    statusInput.value = book.status;
    submitBtn.textContent = "Update Book";
    cancelBtn.style.display = "inline-block";
  }
});

fetchBooks();
